<?php
$nasional = 'SELECT
berita.id_berita,
berita.judul,
berita.gambar,
berita.tgl_posting,
berita.id_admin,
admin.nama_lengkap,
berita.dilihat,
kategori.id_kategori
FROM
berita
INNER JOIN admin ON berita.id_admin = admin.id_admin
INNER JOIN kategori ON kategori.id_kategori = berita.id_kategori
WHERE
berita.id_kategori = "1"
ORDER BY
berita.tgl_posting DESC
LIMIT 0, 5';

$olahraga = 'SELECT
berita.id_berita,
berita.judul,
berita.gambar,
berita.tgl_posting,
berita.id_admin,
admin.nama_lengkap,
berita.dilihat,
kategori.id_kategori
FROM
berita
INNER JOIN admin ON berita.id_admin = admin.id_admin
INNER JOIN kategori ON kategori.id_kategori = berita.id_kategori
WHERE
berita.id_kategori = "2"
ORDER BY
berita.tgl_posting DESC
LIMIT 0, 5';

$teknologi = 'SELECT
berita.id_berita,
berita.judul,
berita.gambar,
berita.tgl_posting,
berita.id_admin,
admin.nama_lengkap,
berita.dilihat,
kategori.id_kategori
FROM
berita
INNER JOIN admin ON berita.id_admin = admin.id_admin
INNER JOIN kategori ON kategori.id_kategori = berita.id_kategori
WHERE
berita.id_kategori = "3"
ORDER BY
berita.tgl_posting DESC
LIMIT 0, 5';

$list_nasional = $mysqli->query($nasional) or die("Error Nasional:".$mysqli->error);
$list_olahraga = $mysqli->query($olahraga) or die("Error Olahraga".$mysqli->error);
$list_teknologi = $mysqli->query($teknologi) or die("Error Teknologi".$mysqli->error);
 ?>
<div class="container-fluid footer">
	<div class="row footer-upper">
		<div class="container">
			<div class="col-md-4">
				<h3 class="page-header">Sosial Media Kami</h3>
				<ul class="news-list">
				<svg style="width:50px;height:50px" viewBox="0 0 24 24">
					<path fill="currentColor" d="M12 2.04C6.5 2.04 2 6.53 2 12.06C2 17.06 5.66 21.21 10.44 21.96V14.96H7.9V12.06H10.44V9.85C10.44 7.34 11.93 5.96 14.22 5.96C15.31 5.96 16.45 6.15 16.45 6.15V8.62H15.19C13.95 8.62 13.56 9.39 13.56 10.18V12.06H16.34L15.89 14.96H13.56V21.96A10 10 0 0 0 22 12.06C22 6.53 17.5 2.04 12 2.04Z" />
				</svg>
				<svg style="width:50px;height:50px" viewBox="0 0 24 24">
					<path fill="currentColor" d="M22.46,6C21.69,6.35 20.86,6.58 20,6.69C20.88,6.16 21.56,5.32 21.88,4.31C21.05,4.81 20.13,5.16 19.16,5.36C18.37,4.5 17.26,4 16,4C13.65,4 11.73,5.92 11.73,8.29C11.73,8.63 11.77,8.96 11.84,9.27C8.28,9.09 5.11,7.38 3,4.79C2.63,5.42 2.42,6.16 2.42,6.94C2.42,8.43 3.17,9.75 4.33,10.5C3.62,10.5 2.96,10.3 2.38,10C2.38,10 2.38,10 2.38,10.03C2.38,12.11 3.86,13.85 5.82,14.24C5.46,14.34 5.08,14.39 4.69,14.39C4.42,14.39 4.15,14.36 3.89,14.31C4.43,16 6,17.26 7.89,17.29C6.43,18.45 4.58,19.13 2.56,19.13C2.22,19.13 1.88,19.11 1.54,19.07C3.44,20.29 5.7,21 8.12,21C16,21 20.33,14.46 20.33,8.79C20.33,8.6 20.33,8.42 20.32,8.23C21.16,7.63 21.88,6.87 22.46,6Z" />
				</svg>
				<svg style="width:50px;height:50px" viewBox="0 0 24 24">
					<path fill="currentColor" d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z" />
				</svg>
			</div>
			<div class="col-md-4">
				<h3 class="page-header">Tentang</h3>
				<p>Kanaya merupakan aplikasi edukasi berbasis website yang bertujuan untuk memperkenalkan budaya Indonesia lebih luas lagi.</p>

			</div>
			<div class="col-md-4">
				<h3 class="page-header">Alamat Kami</h3>
				<ul class="news-list">
				<li><svg style="width:100px;height:45px" viewBox="0 0 24 24">
					<path fill="currentColor" d="M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z" />
				</svg>
				<padding-right:16px>
					<span>
				<p>Jalan Gili Sampeng VI No.27, RT.3/RW.9 Kebon Jeruk, Kebon Jeruk Jakarta Barat 11350  </p>
				</span>
				</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="row footer-bottom">
		<div class="col-md-12">
			
			</span>
		</div>
	</div>
</div>
<script src="<?php echo $base_url; ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo $base_url; ?>assets/ticker/jquery.ticker.min.js"></script>
<script src="<?php echo $base_url; ?>assets/wow/dist/wow.min.js"></script>
<script src="<?php echo $base_url; ?>dist/js/portalberita.js"></script>
</body>
<style>

	
</style>
</html>
