<?php
$base_url = 'http://localhost/kanaya/'; //URL utama website